import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Project, ProjectFormData } from '../types';
import { Input } from './Input';
import { Textarea } from './Textarea';
import { Button } from './Button';

const projectSchema = z.object({
  title: z.string().min(1, 'Title is required'),
  description: z.string().min(10, 'Description must be at least 10 characters'),
  category: z.string().min(1, 'Category is required'),
  location: z.string().min(1, 'Location is required'),
  images: z.array(z.string().url('Please enter valid URLs')).min(1, 'At least one image is required'),
});

interface ProjectFormProps {
  project?: Project | null;
  onSubmit: (data: ProjectFormData) => Promise<void>;
  onCancel: () => void;
  isSubmitting: boolean;
}

export const ProjectForm: React.FC<ProjectFormProps> = ({
  project,
  onSubmit,
  onCancel,
  isSubmitting,
}) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
  } = useForm<ProjectFormData>({
    resolver: zodResolver(projectSchema),
    defaultValues: project ? {
      title: project.title,
      description: project.description,
      category: project.category,
      location: project.location,
      images: project.images,
    } : {
      title: '',
      description: '',
      category: '',
      location: '',
      images: [''],
    },
  });

  const images = watch('images');

  const addImageField = () => {
    setValue('images', [...images, '']);
  };

  const removeImageField = (index: number) => {
    setValue('images', images.filter((_, i) => i !== index));
  };

  const updateImageField = (index: number, value: string) => {
    const newImages = [...images];
    newImages[index] = value;
    setValue('images', newImages);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <Input
        label="Project Title"
        {...register('title')}
        error={errors.title?.message}
        placeholder="Enter project title"
      />

      <Textarea
        label="Description"
        {...register('description')}
        error={errors.description?.message}
        placeholder="Describe the project..."
        rows={4}
      />

      <div className="grid grid-cols-2 gap-4">
        <Input
          label="Category"
          {...register('category')}
          error={errors.category?.message}
          placeholder="e.g., Residential, Commercial"
        />

        <Input
          label="Location"
          {...register('location')}
          error={errors.location?.message}
          placeholder="e.g., New York, NY"
        />
      </div>

      <div className="space-y-3">
        <label className="block text-sm font-medium text-gray-700">
          Project Images
        </label>
        {images.map((image, index) => (
          <div key={index} className="flex space-x-2">
            <Input
              value={image}
              onChange={(e) => updateImageField(index, e.target.value)}
              placeholder="https://example.com/image.jpg"
              className="flex-1"
            />
            {images.length > 1 && (
              <Button
                type="button"
                variant="secondary"
                onClick={() => removeImageField(index)}
              >
                Remove
              </Button>
            )}
          </div>
        ))}
        <Button
          type="button"
          variant="secondary"
          onClick={addImageField}
          size="sm"
        >
          Add Image URL
        </Button>
        {errors.images && (
          <p className="text-sm text-red-600">At least one valid image URL is required</p>
        )}
      </div>

      <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200">
        <Button type="button" variant="secondary" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" loading={isSubmitting}>
          {project ? 'Update Project' : 'Create Project'}
        </Button>
      </div>
    </form>
  );
};