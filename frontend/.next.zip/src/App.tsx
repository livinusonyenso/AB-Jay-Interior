import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import HomePage from "./pages/HomePage";
import AboutPage from "./pages/AboutPage";
import ContactPage from "./pages/ContactPage";
import FAQPage from "./pages/FAQPage";
import GalleryPage from "./pages/GalleryPage";
import ServicesPage from "./pages/ServicesPage";
import ScrollToTop from "../components/ScrollToTop.tsx";
import RequestQuote from "./pages/RequestQuote.tsx";
import "./index.css";
import AdminPanel from "./pages/AdminPanel.tsx";
import { DashboardPage } from "./pages/Admin/DashboardPage.tsx";
import { SubmissionsPage } from "./pages/Admin/SubmissionsPage.tsx";

function App() {
  return (
    <Router>
      <ScrollToTop />
      <div className="min-h-screen">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/faq" element={<FAQPage />} />
          <Route path="/gallery" element={<GalleryPage />} />
          <Route path="/services" element={<ServicesPage />} />
          <Route path="/requestQuote" element={<RequestQuote />} />

          {/* Admin routes */}
          <Route path="/login*" element={<AdminPanel />} />
          <Route path="/admin/dashboard" element={<DashboardPage/>} />
          <Route path="/admin/submissions" element={<SubmissionsPage/>} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
